lst_a= ['justin','devies','clark','tris','paul','justin']
lst_b=['clark', 'tris','tris']
set_a = set(lst_a)
print(set_a)